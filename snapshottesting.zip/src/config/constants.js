export const puppeteerConfig = {
    headless: false,
    slowMo: 250,
    args: ["--disable-gpu", "--no-sandbox", "--disable-setuid-sandbox", `--window-size=${1366},${600}`]
}

export const viewportConfig = { width: 1366, height: 768 };

export const urlsConfig = {
    main: 'https://www.mubadala.com/',
    stage1: 'https://www.mubadala.com/en/inspired-partnerships'
}
