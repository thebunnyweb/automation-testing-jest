import puppeteer from 'puppeteer';
import {puppeteerConfig, viewportConfig, urlsConfig} from '../config/constants'; 

test('inspirepartnership', async ()=> {
 
    const browser = await puppeteer.launch(puppeteerConfig);
    const page = await browser.newPage();

    await page.setViewport(viewportConfig);
    await page.goto(urlsConfig.main, {"waitUntil" : "networkidle0"});
    await page.screenshot({path:'./screenshots/homepage.png', fullPage: true});

    // Stage 2
    let selector = '.nav-primary .menu-3289';
    await page.waitForSelector(selector);
    await page.mouse.down(selector);
    await page.evaluate(()=>{
        let event = new Event('mouseover')
        document.querySelector('.menu-3289 > a').dispatchEvent(event);
    });
    await page.screenshot({path:'./screenshots/openourimpactmenu.png', fullPage: true})

    // Stage 3
    selector = '#ourimpact .l-more-icon';
    expect(await page.evaluate(()=>{
        return document.querySelector('#ourimpact .l-more-icon').getAttribute('href')
    })).toEqual('/en/our-impact');
    await page.waitForSelector(selector);
    await page.click(selector);


    // Stage 4
    selector = '.wrap-our-impact .landing-spotlight-widget .l-more';
    await page.waitForSelector('.landing-spotlight-wrap');
    expect(page.url()).toEqual('https://www.mubadala.com/en/our-impact');
    await page.screenshot({path: './screenshots/ourimpactpage.png', fullPage: true});
    await page.click(selector);

    
    await page.waitFor(5000);
    browser.close();

}, 1000000)